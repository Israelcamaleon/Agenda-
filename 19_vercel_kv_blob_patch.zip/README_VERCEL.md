Patch: Vercel KV + Blob (persistencia serverless)
=================================================

Este patch reemplaza la persistencia en disco por **Vercel KV** (ajustes y horarios)
y **Vercel Blob** (logotipos). Ideal para desplegar en Vercel sin perder datos.

Archivos incluidos
------------------
- `src/app/api/settings/route.ts` → usa **@vercel/kv**
- `src/app/api/locations/[id]/schedule/route.ts` → usa **@vercel/kv**
- `src/app/api/upload/route.ts` → usa **@vercel/blob**
- `.env.example` → variables necesarias en Vercel

Requisitos en tu proyecto
-------------------------
Instala dependencias:
```
npm i @vercel/kv @vercel/blob
```

Configura Storage en Vercel:
1) En tu dashboard Vercel → **Storage** → **Add** → crea **KV** → **Link** a tu proyecto.
   - Esto inyecta `KV_REST_API_URL` y `KV_REST_API_TOKEN` automáticamente.
2) En **Storage → Blob** → **Enable** y genera un **READ/WRITE token**.
   - Añádelo en **Project → Settings → Environment Variables**: `BLOB_READ_WRITE_TOKEN`.
3) (Deploy con Preview/Production) → asegúrate de que las variables existan en ambos entornos si los usas.

Flujo de deploy recomendado
---------------------------
- Sube tu repo a GitHub.
- En Vercel: **New Project → Import Git Repository**.
- Desde la UI de Vercel agrega **KV** y **Blob**, y las variables.
- Build command: `next build` (por defecto).

Notas
-----
- El endpoint `/api/upload` devuelve `url` público del blob. Tus vistas usan `<img src={logoUrl} />`, por lo que no necesitas `next/image` ni `next.config.js` adicional.
- Ajustes: clave `app:settings` en KV (hash). 
- Horarios: clave `schedule:{id}`.

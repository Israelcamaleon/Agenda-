import { NextResponse } from 'next/server'
import { kv } from '@vercel/kv'

type DayKey = 'mon'|'tue'|'wed'|'thu'|'fri'|'sat'|'sun'
type Day = { open: boolean, start: string, end: string }
type Schedule = Record<DayKey, Day>

function defaultSchedule(): Schedule{
  return {
    mon: { open:true, start:'09:00', end:'18:00' },
    tue: { open:true, start:'09:00', end:'18:00' },
    wed: { open:true, start:'09:00', end:'18:00' },
    thu: { open:true, start:'09:00', end:'18:00' },
    fri: { open:true, start:'09:00', end:'18:00' },
    sat: { open:true, start:'10:00', end:'14:00' },
    sun: { open:false, start:'00:00', end:'00:00' },
  }
}

export async function GET(req: Request, { params }: { params: { id: string } }){
  const id = Number(params.id)
  if (!id) return NextResponse.json({ error: 'invalid id' }, { status: 400 })
  const key = `schedule:${id}`
  const raw = await kv.get<Schedule>(key)
  const data = raw || defaultSchedule()
  return NextResponse.json(data)
}

export async function PATCH(req: Request, { params }: { params: { id: string } }){
  const id = Number(params.id)
  if (!id) return NextResponse.json({ error: 'invalid id' }, { status: 400 })
  const body = await req.json()
  if (!body || typeof body !== 'object') return NextResponse.json({ error: 'invalid body' }, { status: 400 })
  const days: DayKey[] = ['mon','tue','wed','thu','fri','sat','sun']
  for(const d of days){
    const v = (body as any)[d]
    if (!v) continue
    if (typeof v.open !== 'boolean') return NextResponse.json({ error: `invalid ${d}.open` }, { status: 400 })
    if (typeof v.start !== 'string' || !/^\d{2}:\d{2}$/.test(v.start)) return NextResponse.json({ error: `invalid ${d}.start` }, { status: 400 })
    if (typeof v.end !== 'string'   || !/^\d{2}:\d{2}$/.test(v.end))   return NextResponse.json({ error: `invalid ${d}.end` }, { status: 400 })
  }
  const key = `schedule:${id}`
  await kv.set(key, body)
  return NextResponse.json(body)
}

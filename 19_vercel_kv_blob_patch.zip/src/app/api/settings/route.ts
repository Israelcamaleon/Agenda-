import { NextResponse } from 'next/server'
import { kv } from '@vercel/kv'

type Settings = {
  businessName: string
  address: string
  logoUrl?: string | null
}

function normalize(input: any): Settings {
  return {
    businessName: typeof input?.businessName === 'string' ? input.businessName : '',
    address: typeof input?.address === 'string' ? input.address : '',
    logoUrl: (typeof input?.logoUrl === 'string' || input?.logoUrl === null) ? input.logoUrl : null,
  }
}

const KEY = 'app:settings'

export async function GET(){
  const raw = await kv.hgetall<Settings>(KEY)
  const s = normalize(raw || {})
  return NextResponse.json(s)
}

export async function PATCH(req: Request){
  const body = await req.json()
  const businessName = typeof body.businessName === 'string' ? body.businessName.trim() : ''
  const address = typeof body.address === 'string' ? body.address.trim() : ''
  const logoUrl = (typeof body.logoUrl === 'string' || body.logoUrl === null) ? body.logoUrl : null
  if (!businessName) return NextResponse.json({ error: 'businessName es requerido' }, { status: 400 })

  const s: Settings = { businessName, address, logoUrl }
  await kv.hset(KEY, s as any)
  return NextResponse.json(s)
}

Arreglo de 404 en Vercel (página raíz)
======================================
Este ZIP agrega:
- src/app/page.tsx  → portada simple con links a /dashboard, /book y /ajustes
- vercel.json       → base para futuras rewrites (opcional)
- README_404.md     → instrucciones

Uso:
1) Descomprime este ZIP en la **raíz de tu proyecto** (respeta rutas).
2) Haz commit & push a GitHub. Vercel hará el deploy.
3) Abre la URL raíz del proyecto: ya no debe mostrar 404.

Si el 404 persiste:
- En Vercel → Project Settings → **Root Directory**: apunta al folder que tiene tu package.json.
- Revisa los build logs para confirmar que Next detecta `src/app/page.tsx`.
export default function Home(){
  return (
    <div className="max-w-5xl mx-auto py-12 space-y-6">
      <h1 className="text-2xl font-semibold">Bienvenido</h1>
      <p className="text-neutral-600">Elige a dónde ir:</p>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <a href="/dashboard" className="border rounded-lg p-4 hover:bg-neutral-50">
          <div className="font-medium">Dashboard</div>
          <div className="text-sm opacity-70">Indicadores y módulos</div>
        </a>
        <a href="/book" className="border rounded-lg p-4 hover:bg-neutral-50">
          <div className="font-medium">Nueva cita</div>
          <div className="text-sm opacity-70">Agenda una nueva cita</div>
        </a>
        <a href="/ajustes" className="border rounded-lg p-4 hover:bg-neutral-50">
          <div className="font-medium">Ajustes</div>
          <div className="text-sm opacity-70">General, Sucursales, Roles</div>
        </a>
      </div>
    </div>
  )
}
